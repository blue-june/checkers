import javax.swing.JPanel;

@SuppressWarnings("serial")
public class GameBoard extends JPanel {
    
}