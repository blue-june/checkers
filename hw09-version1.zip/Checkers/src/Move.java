/**
 * This class is a model for a move in Checkers.
 */
public class Move {
    
    public Move(int startx, int starty, int endx, int endy, int[][] board) {
        
    }
}
