
public class Piece {
    private boolean player;
    
    public Piece(boolean player) {
        this.player = player;
    }
    
    /**
     * Returns TRUE for player1.
     * Returns FALSE for player2.
     *
     */
    public boolean getPlayer() {
        boolean b = this.player;
        return b;
    }

}
