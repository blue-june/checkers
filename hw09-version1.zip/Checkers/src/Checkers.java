import java.util.LinkedList;
import java.util.List;

/**
 * This class is a model for Checkers.
 * 
 * This game adheres to a Model-View-Controller design framework.
 */
public class Checkers {
    
    private int[][] board;
    private boolean player1;
    private boolean gameOver;
    private List<Move> moves;
    private List<Piece> player1Pieces;
    private List<Piece> player2Pieces;
    
    public Checkers() {
        reset();
    }
    
    
    /**
     * Sets up a new Checkers game.
     *
     */
    public void reset() {
        this.board = new int[8][8];
            setBoard(board);
        this.player1 = true;
        this.gameOver = false;
        this.moves = new LinkedList<Move>();
        this.player1Pieces = new LinkedList<Piece>();
        this.player2Pieces = new LinkedList<Piece>();
        
        // add the pieces into the players' lists of pieces
        for (int i = 0; i < 12; i++) {
            player1Pieces.add(new Piece(true));
            player2Pieces.add(new Piece(false));
        }
    }
    
    /**
     * First, set the board to contain "playable"
     * and "non-playable" squares. Playable squares
     * will be initiated to a value of 0. 
     * Non-playable squares will be initiated to
     * a value of -1.
     * 
     * Then, set up the board
     * to begin the Checkers game. Each player should have
     * twelve pieces arrayed on their side of the board.
     * 
     * The pieces should be on playable squares only.
     *
     */
    private void setBoard(int[][] board) {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                
                // playable squares
                if ((row % 2 == 1 && col % 2 == 0) 
                        || (row % 2 == 0 && col % 2 == 1)) {
                    board[row][col] = 0;
                }
                
                //non-playable squares
                else {
                    board[row][col] = -1;
                }
            }
        }
    }
    
    /**
     * Returns TRUE for player1
     * Returns FALSE for player2
     *
     */
    public boolean getCurrentPlayer() {
        boolean b = this.player1;
        return b;
    }
    
    /**
     * This method returns TRUE if the move is successful
     * and FALSE if the square is already taken, the start
     * square was empty/invalid, or if the 
     * player tried to move to an illegal square. 
     * 
     * If the move is successful, then the move should be added to
     * the LinkedList moves.
     * 
     * The current player should be toggled if the 
     * game is not yet over. If the game is over, then the player
     * is not toggled.
     *
     */
    public boolean playTurn() {
        //TODO implement playTurn.
        return false;
    }
    
    /**
     * This method removes the most recent Move
     * off of the LinkedList of Moves. The game should return to
     * the state it was in before that most recent Move.
     * The current player should not change.
     *
     */
    public void undoMove() {
        //TODO implement undoMove
    }
    
    /**
     * This method returns 1 if player1 has won,
     * 2 if player2 has won, and 3 if it's a stalemate.
     * If there is not yet a winner, this method returns 0.
     *
     * This should also update gameOver to TRUE 
     * when someone wins.
     */
    public int checkWinner() {
        //TODO implement checkWinner.
        return 0;
    }
    
    /**
     * printGameState prints the current game state
     * for debugging.
     */
    public void printGameState() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                System.out.print(board[i][j]);
                if (j < 7) { 
                    System.out.print(" | "); 
                }
            }
            if (i < 7) {
                System.out.println("\n-----------------" + 
                                    "----------------"); 
            }
        }
    }
    
    public static void main(String[] args) {
        Checkers checkers = new Checkers();
        checkers.printGameState();
    }


}
